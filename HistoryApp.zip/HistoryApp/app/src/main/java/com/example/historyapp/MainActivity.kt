package com.example.historyapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val clearButton: Button = findViewById(R.id.clearButton)
        val calculateButton: Button = findViewById(R.id.calculateButton)
        val resultText: TextView = findViewById(R.id.resultText)
        val ageInput: EditText = findViewById(R.id.ageInput)

        calculateButton.setOnClickListener {
            val age = ageInput.text.toString().toIntOrNull()
            if (age != null) {
                resultText.text = "Nelson Mandela passed away at this age\" to 95"
                resultText.text = "William Shakespeare died at this age\" to 54"
                resultText.text = "Malala Yousafzai became the youngest Nobel Prize laureate\" to 25"
                resultText.text = "Thomas Jefferson drafted the Declaration of Independence\" to 33"
                resultText.text = "Queen Elizabeth II celebrated her 80th birthday in 2006\" to 80"
                resultText.text = "John Glenn became the oldest person to fly in space\" to 77"
                resultText.text = "Betty White started her acting career \" to 61"
                resultText.text = "Colonel Harland Sanders found Kentucky Fried Chicken (KFC)\" to 65"
                resultText.text = "J.K. Rowling published the first Harry Potter book\" to 43"
                resultText.text = "Steve Jobs introduced the first iPhone"
            } else {
                resultText.text = "Please enter a valid age"
            }
        }

        clearButton.setOnClickListener {
            ageInput.text.clear()
            resultText.text =""
        }
    }

}
