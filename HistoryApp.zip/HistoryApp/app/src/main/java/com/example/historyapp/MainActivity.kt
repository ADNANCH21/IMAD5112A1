package com.example.historyapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private val famousPeople = listOf(
        "Nelson Mandela passed away at this age" to 95,
        "William Shakespeare died at this age" to 52,
        "Malala Yousafzai became the youngest Nobel Prize laureate" to 23,
        "Thomas Jefferson drafted the Declaration of Independence" to 33,
        "Queen Elizabeth II celebrated her 80th birthday in 2006" to 80,
        "John Glenn became the oldest person to fly in space" to 77,
        "Betty White started her acting career " to 61,
        "Colonel Harland Sanders found Kentucky Fried Chicken (KFC)" to 65,
        "J.K. Rowling published the first Harry Potter book" to 43,
        "Steve Jobs introduced the first iPhone " to 36,
        "Bill Gates dropped out of Harvard University to co-found Microsoft " to 28,
        "Martin Luther King Jr. delivered his famous \"I Have a Dream\" speech" to 41,
        "Winston Churchill was appointed Prime Minister of the United Kingdom" to 59,
    )
    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var clearButton: Button = findViewById(R.id.clearButton)
        var calculateButton: Button = findViewById(R.id.calculateButton)
        var resultText: TextView = findViewById(R.id.resultText)
        var heading: TextView = findViewById(R.id.heading)
        val ageInput: EditText = findViewById(R.id.ageInput)

        calculateButton.setOnClickListener {
            val age = ageInput.text.toString().toIntOrNull()
            if (age != null) {
                val person = findPersonByAge(age)
                if (person != null) {
                    resultText.text = "Famous person who died at age $age: $person"
                } else {
                    resultText.text = "No famous person found who died at age $age"
                }
            } else {
                resultText.text = "Please enter a valid age"
            }
        }

        clearButton.setOnClickListener {
            ageInput.text.clear()
            resultText.text =""
        }
    }

    private fun findPersonByAge(age: Int) {" \"Nelson Mandela passed away at this age\" to 95,\n" +
            "        \"William Shakespeare died at this age\" to 52,\n" +
            "        \"Malala Yousafzai became the youngest Nobel Prize laureate\" to 23,\n" +
            "        \"Thomas Jefferson drafted the Declaration of Independence\" to 33,\n" +
            "        \"Queen Elizabeth II celebrated her 80th birthday in 2006\" to 80,\n" +
            "        \"John Glenn became the oldest person to fly in space\" to 77,\n" +
            "        \"Betty White started her acting career \" to 61,\n" +
            "        \"Colonel Harland Sanders found Kentucky Fried Chicken (KFC)\" to 65,\n" +
            "        \"J.K. Rowling published the first Harry Potter book\" to 43,\n" +
            "        \"Steve Jobs introduced the first iPhone \" to 36,\n" +
            "        \"Bill Gates dropped out of Harvard University to co-found Microsoft \" to 28,\n" +
            "        \"Martin Luther King Jr. delivered his famous \\\"I Have a Dream\\\" speech\" to 41,\n" +
            "        \"Winston Churchill was appointed Prime Minister of the United Kingdom\" to 59,"
    }

    }
